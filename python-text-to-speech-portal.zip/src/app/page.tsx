import TtsPortal from "@/components/TtsPortal";

export default function Home() {
  return <TtsPortal />;
}
