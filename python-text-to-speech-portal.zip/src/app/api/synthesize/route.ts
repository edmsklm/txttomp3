import { runTts, type Voice } from "@/lib/tts";
import { db } from "@/db";
import { conversions } from "@/db/schema";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const VALID_VOICES: Voice[] = ["male", "female", "neutral"];
const VALID_ACCENTS = [
  "com",
  "co.uk",
  "com.au",
  "co.in",
  "ca",
  "ie",
  "co.za",
];

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const data = body as {
    text?: string;
    voice?: string;
    accent?: string;
    slow?: boolean;
    save?: boolean;
  };

  const text = (data.text || "").trim();
  const voice = (VALID_VOICES.includes(data.voice as Voice)
    ? data.voice
    : "female") as Voice;
  const accent = VALID_ACCENTS.includes(data.accent || "")
    ? (data.accent as string)
    : "com";
  const slow = Boolean(data.slow);
  const save = data.save !== false;

  if (!text) {
    return Response.json({ error: "Text is required" }, { status: 400 });
  }
  if (text.length > 5000) {
    return Response.json(
      { error: "Text must be 5000 characters or fewer" },
      { status: 400 }
    );
  }

  const result = await runTts({ text, voice, accent, slow });

  if (!result.ok || !result.mp3_base64) {
    return Response.json(
      { error: result.error || "Synthesis failed" },
      { status: 502 }
    );
  }

  let id: number | null = null;
  if (save) {
    try {
      const [row] = await db
        .insert(conversions)
        .values({
          text,
          voice,
          accent,
          charCount: text.length,
          fileSize: result.size ?? 0,
          audioBase64: result.mp3_base64,
        })
        .returning({ id: conversions.id });
      id = row?.id ?? null;
    } catch {
      // Non-fatal: still return the audio even if persistence fails.
      id = null;
    }
  }

  return Response.json({
    ok: true,
    id,
    audio: `data:audio/mpeg;base64,${result.mp3_base64}`,
    size: result.size ?? 0,
    duration: result.duration ?? 0,
    voice,
    accent,
  });
}
