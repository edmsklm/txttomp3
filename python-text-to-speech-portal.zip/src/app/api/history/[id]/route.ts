import { db } from "@/db";
import { conversions } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const numId = Number(id);
  if (!Number.isFinite(numId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }

  try {
    const [row] = await db
      .select()
      .from(conversions)
      .where(eq(conversions.id, numId))
      .limit(1);

    if (!row) {
      return Response.json({ error: "Not found" }, { status: 404 });
    }

    const bytes = Buffer.from(row.audioBase64, "base64");
    return new Response(new Uint8Array(bytes), {
      headers: {
        "Content-Type": "audio/mpeg",
        "Content-Disposition": `attachment; filename="voice-${row.id}.mp3"`,
        "Cache-Control": "no-store",
      },
    });
  } catch {
    return Response.json({ error: "Failed to load audio" }, { status: 500 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const numId = Number(id);
  if (!Number.isFinite(numId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }
  try {
    await db.delete(conversions).where(eq(conversions.id, numId));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Failed to delete" }, { status: 500 });
  }
}
