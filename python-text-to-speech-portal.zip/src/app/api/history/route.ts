import { db } from "@/db";
import { conversions } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: conversions.id,
        text: conversions.text,
        voice: conversions.voice,
        accent: conversions.accent,
        charCount: conversions.charCount,
        fileSize: conversions.fileSize,
        createdAt: conversions.createdAt,
      })
      .from(conversions)
      .orderBy(desc(conversions.createdAt))
      .limit(30);

    return Response.json({ items: rows });
  } catch {
    return Response.json({ items: [] });
  }
}
