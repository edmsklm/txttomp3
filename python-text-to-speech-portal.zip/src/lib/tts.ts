import { spawn, spawnSync } from "node:child_process";
import path from "node:path";

export type Voice = "male" | "female" | "neutral";

export interface TtsRequest {
  text: string;
  voice: Voice;
  accent: string;
  slow?: boolean;
}

export interface TtsResult {
  ok: boolean;
  mp3_base64?: string;
  size?: number;
  duration?: number;
  error?: string;
}

const SCRIPT_PATH = path.join(process.cwd(), "scripts", "tts.py");

function findPython(): string {
  return process.env.PYTHON_BIN || "python3";
}

let depsReady = false;

/**
 * Ensure the Python speech dependencies are installed. Runs once per process.
 * Safe to call repeatedly — it becomes a no-op after the first success.
 */
function ensureDeps(): void {
  if (depsReady) return;
  const py = findPython();
  const check = spawnSync(
    py,
    ["-c", "import gtts, numpy, miniaudio, lameenc"],
    { encoding: "utf8" }
  );
  if (check.status === 0) {
    depsReady = true;
    return;
  }
  const reqPath = path.join(process.cwd(), "requirements.txt");
  spawnSync(
    py,
    [
      "-m",
      "pip",
      "install",
      "--break-system-packages",
      "--quiet",
      "-r",
      reqPath,
    ],
    { encoding: "utf8", timeout: 180_000 }
  );
  const recheck = spawnSync(
    py,
    ["-c", "import gtts, numpy, miniaudio, lameenc"],
    { encoding: "utf8" }
  );
  depsReady = recheck.status === 0;
}

/**
 * Invoke the Python text-to-speech engine, sending the request via stdin
 * and parsing the JSON result from stdout.
 */
export function runTts(req: TtsRequest): Promise<TtsResult> {
  return new Promise((resolve) => {
    try {
      ensureDeps();
    } catch {
      /* fall through; script will report a missing-dependency error */
    }
    const py = findPython();
    const child = spawn(py, [SCRIPT_PATH], {
      cwd: process.cwd(),
      env: process.env,
    });

    let stdout = "";
    let stderr = "";
    const killTimer = setTimeout(() => {
      child.kill("SIGKILL");
    }, 90_000);

    child.stdout.on("data", (d) => (stdout += d.toString()));
    child.stderr.on("data", (d) => (stderr += d.toString()));

    child.on("error", (err) => {
      clearTimeout(killTimer);
      resolve({ ok: false, error: `Failed to start Python: ${err.message}` });
    });

    child.on("close", () => {
      clearTimeout(killTimer);
      const trimmed = stdout.trim();
      if (!trimmed) {
        resolve({
          ok: false,
          error: stderr.trim() || "No output from TTS engine",
        });
        return;
      }
      try {
        const parsed = JSON.parse(trimmed) as TtsResult;
        resolve(parsed);
      } catch {
        resolve({
          ok: false,
          error: `Invalid TTS output: ${trimmed.slice(0, 200)}`,
        });
      }
    });

    child.stdin.write(JSON.stringify(req));
    child.stdin.end();
  });
}
