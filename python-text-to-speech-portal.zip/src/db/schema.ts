import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  timestamp,
} from "drizzle-orm/pg-core";

// Stores each text-to-speech conversion so users can revisit past audio.
export const conversions = pgTable("conversions", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  voice: varchar("voice", { length: 32 }).notNull(),
  accent: varchar("accent", { length: 32 }).notNull(),
  charCount: integer("char_count").notNull().default(0),
  fileSize: integer("file_size").notNull().default(0),
  audioBase64: text("audio_base64").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Conversion = typeof conversions.$inferSelect;
export type NewConversion = typeof conversions.$inferInsert;
