"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

type Voice = "male" | "female" | "neutral";

interface HistoryItem {
  id: number;
  text: string;
  voice: string;
  accent: string;
  charCount: number;
  fileSize: number;
  createdAt: string;
}

interface SynthResponse {
  ok?: boolean;
  id?: number | null;
  audio?: string;
  size?: number;
  duration?: number;
  voice?: string;
  accent?: string;
  error?: string;
}

const VOICES: {
  id: Voice;
  label: string;
  emoji: string;
  desc: string;
}[] = [
  { id: "female", label: "Female", emoji: "👩", desc: "Bright, higher pitch" },
  { id: "male", label: "Male", emoji: "👨", desc: "Deep, lower pitch" },
  { id: "neutral", label: "Neutral", emoji: "🧑", desc: "Natural default" },
];

const ACCENTS = [
  { id: "com", label: "US English 🇺🇸" },
  { id: "co.uk", label: "British 🇬🇧" },
  { id: "com.au", label: "Australian 🇦🇺" },
  { id: "co.in", label: "Indian 🇮🇳" },
  { id: "ca", label: "Canadian 🇨🇦" },
  { id: "ie", label: "Irish 🇮🇪" },
  { id: "co.za", label: "South African 🇿🇦" },
];

const SAMPLE =
  "Welcome to VoxForge, your text to speech portal. Type any text and choose a male or female voice to generate an MP3 audio file.";

function formatBytes(n: number): string {
  if (!n) return "0 B";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

export default function TtsPortal() {
  const [text, setText] = useState(SAMPLE);
  const [voice, setVoice] = useState<Voice>("female");
  const [accent, setAccent] = useState("com");
  const [slow, setSlow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SynthResponse | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  const charCount = text.length;
  const overLimit = charCount > 5000;

  const loadHistory = useCallback(async () => {
    try {
      const res = await fetch("/api/history", { cache: "no-store" });
      const data = (await res.json()) as { items: HistoryItem[] };
      setHistory(data.items || []);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    void loadHistory();
  }, [loadHistory]);

  const generate = useCallback(async () => {
    setError(null);
    if (!text.trim()) {
      setError("Please enter some text to convert.");
      return;
    }
    if (overLimit) {
      setError("Text exceeds the 5000 character limit.");
      return;
    }
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch("/api/synthesize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voice, accent, slow, save: true }),
      });
      const data = (await res.json()) as SynthResponse;
      if (!res.ok || !data.ok) {
        setError(data.error || "Something went wrong while generating audio.");
      } else {
        setResult(data);
        void loadHistory();
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [text, voice, accent, slow, overLimit, loadHistory]);

  const download = useCallback(() => {
    if (!result?.audio) return;
    const a = document.createElement("a");
    a.href = result.audio;
    a.download = `voxforge-${voice}-${Date.now()}.mp3`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }, [result, voice]);

  const deleteItem = useCallback(
    async (id: number) => {
      try {
        await fetch(`/api/history/${id}`, { method: "DELETE" });
        void loadHistory();
      } catch {
        /* ignore */
      }
    },
    [loadHistory]
  );

  const counterColor = useMemo(
    () => (overLimit ? "text-rose-400" : "text-slate-400"),
    [overLimit]
  );

  return (
    <main className="mx-auto max-w-5xl px-4 py-10 sm:py-14">
      {/* Header */}
      <header className="mb-10 text-center">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-indigo-500/30 bg-indigo-500/10 px-4 py-1.5 text-xs font-medium text-indigo-300">
          <span className="h-2 w-2 animate-pulse rounded-full bg-indigo-400" />
          Powered by a Python speech engine
        </div>
        <h1 className="bg-gradient-to-r from-indigo-400 via-sky-400 to-emerald-400 bg-clip-text text-4xl font-extrabold tracking-tight text-transparent sm:text-5xl">
          VoxForge
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-sm text-slate-400 sm:text-base">
          Turn any text into a downloadable MP3 audio file. Choose a{" "}
          <span className="text-slate-200">male</span> or{" "}
          <span className="text-slate-200">female</span> voice and an accent.
        </p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        {/* Left: composer */}
        <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 shadow-xl backdrop-blur sm:p-6">
          <label className="mb-2 block text-sm font-semibold text-slate-200">
            Your text
          </label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={7}
            placeholder="Type or paste text here..."
            className="w-full resize-y rounded-xl border border-slate-700 bg-slate-950/70 p-4 text-sm text-slate-100 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30"
          />
          <div className="mt-2 flex items-center justify-between text-xs">
            <button
              onClick={() => setText(SAMPLE)}
              className="text-indigo-400 hover:text-indigo-300"
            >
              Insert sample text
            </button>
            <span className={counterColor}>{charCount} / 5000</span>
          </div>

          {/* Voice picker */}
          <div className="mt-6">
            <p className="mb-2 text-sm font-semibold text-slate-200">Voice</p>
            <div className="grid grid-cols-3 gap-3">
              {VOICES.map((v) => {
                const active = voice === v.id;
                return (
                  <button
                    key={v.id}
                    onClick={() => setVoice(v.id)}
                    className={`rounded-xl border p-3 text-center transition ${
                      active
                        ? "border-indigo-500 bg-indigo-500/15 ring-2 ring-indigo-500/30"
                        : "border-slate-700 bg-slate-950/50 hover:border-slate-600"
                    }`}
                  >
                    <div className="text-2xl">{v.emoji}</div>
                    <div className="mt-1 text-sm font-semibold text-slate-100">
                      {v.label}
                    </div>
                    <div className="text-[11px] text-slate-400">{v.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Accent + speed */}
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-semibold text-slate-200">
                Accent
              </label>
              <select
                value={accent}
                onChange={(e) => setAccent(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950/70 p-3 text-sm text-slate-100 outline-none focus:border-indigo-500"
              >
                {ACCENTS.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-2 block text-sm font-semibold text-slate-200">
                Speed
              </label>
              <button
                onClick={() => setSlow((s) => !s)}
                className={`flex w-full items-center justify-between rounded-xl border p-3 text-sm transition ${
                  slow
                    ? "border-emerald-500 bg-emerald-500/10 text-emerald-300"
                    : "border-slate-700 bg-slate-950/70 text-slate-200"
                }`}
              >
                <span>{slow ? "Slow & clear" : "Normal speed"}</span>
                <span
                  className={`h-5 w-9 rounded-full p-0.5 transition ${
                    slow ? "bg-emerald-500" : "bg-slate-600"
                  }`}
                >
                  <span
                    className={`block h-4 w-4 rounded-full bg-white transition ${
                      slow ? "translate-x-4" : ""
                    }`}
                  />
                </span>
              </button>
            </div>
          </div>

          <button
            onClick={generate}
            disabled={loading || overLimit}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 px-5 py-3.5 text-sm font-semibold text-white shadow-lg transition hover:from-indigo-500 hover:to-sky-500 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? (
              <>
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                Generating audio…
              </>
            ) : (
              <>🔊 Convert to MP3</>
            )}
          </button>

          {error && (
            <p className="mt-4 rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
              {error}
            </p>
          )}

          {result?.audio && (
            <div className="mt-5 rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4">
              <div className="mb-3 flex flex-wrap items-center gap-2 text-xs text-slate-300">
                <span className="rounded-full bg-slate-800 px-2.5 py-1 capitalize">
                  {result.voice} voice
                </span>
                <span className="rounded-full bg-slate-800 px-2.5 py-1">
                  {formatBytes(result.size || 0)}
                </span>
                <span className="rounded-full bg-slate-800 px-2.5 py-1">
                  {result.duration}s
                </span>
              </div>
              <audio
                controls
                src={result.audio}
                className="w-full"
                autoPlay
              />
              <button
                onClick={download}
                className="mt-3 w-full rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-4 py-2.5 text-sm font-semibold text-emerald-300 transition hover:bg-emerald-500/20"
              >
                ⬇ Download MP3
              </button>
            </div>
          )}
        </section>

        {/* Right: history */}
        <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 shadow-xl backdrop-blur sm:p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-200">
              Recent conversions
            </h2>
            <button
              onClick={() => void loadHistory()}
              className="text-xs text-indigo-400 hover:text-indigo-300"
            >
              Refresh
            </button>
          </div>

          {history.length === 0 ? (
            <p className="rounded-lg border border-dashed border-slate-700 p-6 text-center text-sm text-slate-500">
              No conversions yet. Generate your first audio file!
            </p>
          ) : (
            <ul className="space-y-3">
              {history.map((h) => (
                <li
                  key={h.id}
                  className="rounded-xl border border-slate-800 bg-slate-950/50 p-3"
                >
                  <p className="line-clamp-2 text-sm text-slate-200">
                    {h.text}
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-400">
                    <span className="rounded bg-slate-800 px-2 py-0.5 capitalize">
                      {h.voice}
                    </span>
                    <span className="rounded bg-slate-800 px-2 py-0.5">
                      {h.accent}
                    </span>
                    <span className="rounded bg-slate-800 px-2 py-0.5">
                      {formatBytes(h.fileSize)}
                    </span>
                    <span className="ml-auto">{formatDate(h.createdAt)}</span>
                  </div>
                  <div className="mt-2 flex gap-2">
                    <a
                      href={`/api/history/${h.id}`}
                      className="flex-1 rounded-lg border border-slate-700 px-3 py-1.5 text-center text-xs font-medium text-slate-200 transition hover:border-indigo-500 hover:text-indigo-300"
                    >
                      ⬇ Download
                    </a>
                    <button
                      onClick={() => void deleteItem(h.id)}
                      className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs font-medium text-rose-400 transition hover:border-rose-500/50 hover:bg-rose-500/10"
                    >
                      Delete
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <footer className="mt-12 text-center text-xs text-slate-600">
        VoxForge · Next.js + Drizzle + PostgreSQL · Python (gTTS + numpy +
        lameenc) speech engine
      </footer>
    </main>
  );
}
