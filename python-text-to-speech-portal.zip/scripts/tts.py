#!/usr/bin/env python3
"""Text-to-Speech engine.

Reads a JSON request from stdin:
    { "text": "...", "voice": "male|female|neutral", "accent": "com|co.uk|com.au|co.in|ca|ie|co.za", "slow": false }

Writes a JSON response to stdout:
    { "ok": true, "mp3_base64": "...", "size": 12345, "duration": 3.2 }
    { "ok": false, "error": "message" }

Pipeline:
  1. gTTS  -> synthesize real, intelligible speech (MP3)
  2. miniaudio -> decode MP3 to raw PCM
  3. numpy -> pitch/timbre shift to create distinct male & female voices
  4. lameenc -> re-encode to MP3
"""
import sys
import json
import base64
import io


def fail(msg: str) -> None:
    sys.stdout.write(json.dumps({"ok": False, "error": str(msg)}))
    sys.stdout.flush()
    sys.exit(0)


def main() -> None:
    try:
        raw = sys.stdin.read()
        req = json.loads(raw or "{}")
    except Exception as exc:  # noqa: BLE001
        fail(f"invalid request: {exc}")
        return

    text = (req.get("text") or "").strip()
    voice = (req.get("voice") or "female").lower()
    accent = req.get("accent") or "com"
    slow = bool(req.get("slow", False))

    if not text:
        fail("Text is required")
        return
    if len(text) > 5000:
        fail("Text must be 5000 characters or fewer")
        return

    valid_accents = {"com", "co.uk", "com.au", "co.in", "ca", "ie", "co.za"}
    if accent not in valid_accents:
        accent = "com"

    try:
        import numpy as np
        import miniaudio
        import lameenc
        from gtts import gTTS
    except Exception as exc:  # noqa: BLE001
        fail(f"missing dependency: {exc}")
        return

    # 1. Synthesize base speech
    try:
        tts = gTTS(text=text, lang="en", tld=accent, slow=slow)
        buf = io.BytesIO()
        tts.write_to_fp(buf)
        base_mp3 = buf.getvalue()
    except Exception as exc:  # noqa: BLE001
        fail(f"synthesis failed (network required): {exc}")
        return

    # 2. Decode MP3 -> PCM
    try:
        dec = miniaudio.decode(base_mp3)
        sr = dec.sample_rate
        channels = dec.nchannels
        data = np.array(dec.samples, dtype=np.int16).reshape(-1, channels)
        mono = data.astype(np.float32).mean(axis=1)
    except Exception as exc:  # noqa: BLE001
        fail(f"decode failed: {exc}")
        return

    # 3. Voice character: shift pitch by resampling.
    # < 1.0 lowers pitch (masculine), > 1.0 raises pitch (feminine).
    if voice == "male":
        factor = 0.84
    elif voice == "female":
        factor = 1.12
    else:  # neutral
        factor = 1.0

    if factor != 1.0 and len(mono) > 4:
        n = len(mono)
        idx = np.arange(0, n - 1, factor)
        i0 = idx.astype(np.int64)
        frac = idx - i0
        mono = mono[i0] * (1.0 - frac) + mono[i0 + 1] * frac

    # gentle normalization to keep a consistent loudness
    peak = float(np.max(np.abs(mono))) if mono.size else 0.0
    if peak > 0:
        mono = mono * (0.95 * 32767.0 / peak)

    pcm = np.clip(mono, -32768, 32767).astype(np.int16)
    duration = round(len(pcm) / float(sr), 2) if sr else 0.0

    # 4. Encode to MP3
    try:
        enc = lameenc.Encoder()
        enc.set_bit_rate(128)
        enc.set_in_sample_rate(sr)
        enc.set_channels(1)
        enc.set_quality(2)
        out = enc.encode(pcm.tobytes()) + enc.flush()
    except Exception as exc:  # noqa: BLE001
        fail(f"encode failed: {exc}")
        return

    sys.stdout.write(
        json.dumps(
            {
                "ok": True,
                "mp3_base64": base64.b64encode(out).decode("ascii"),
                "size": len(out),
                "duration": duration,
            }
        )
    )
    sys.stdout.flush()


if __name__ == "__main__":
    main()
